---
"water.css": patch
---

Added a theme toggle button to the bookmarklet
