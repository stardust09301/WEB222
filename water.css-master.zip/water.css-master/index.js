const gulpfile = require('./gulpfile')
gulpfile.watch()
